/* Copyright 2020-2022 The MathWorks, Inc.*/
#ifndef _MW_COMMON_H_
#define _MW_COMMON_H_

#include "rtwtypes.h"

#define __MATLAB_SERVER_VERSION_YEAR   (25)   /* Release year */
#define __MATLAB_SERVER_VERSION_REL     (1)   /* 1 for 'a', 2 for 'b' */
#define __MATLAB_SERVER_VERSION_BUILD   (0)   /* Build number */

#ifdef _DEBUG
   #define LOG_PRINT(fd, format, ...) fprintf(fd, format, __VA_ARGS__); fflush(fd)
#else 
   #define LOG_PRINT(fd, msg, ...)
#endif 

#endif /* _MW_COMMON_H_ */
