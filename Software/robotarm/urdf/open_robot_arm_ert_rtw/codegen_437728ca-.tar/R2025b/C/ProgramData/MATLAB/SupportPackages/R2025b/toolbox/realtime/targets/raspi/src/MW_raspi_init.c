/* Copyright 2018-2024 The MathWorks, Inc. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "MW_raspi_init.h"
#include "linuxTimeLogger.h"

#if defined(MW_RASPI_ROTARYENCODER) || defined(MW_PWMBLOCK)
#include <pigpio.h>
#endif

uint64_t mwProgramStartTimeOffset = 0;

// Overrun detection function
void mwRaspiInit(void)
{
#if defined(MW_RASPI_ROTARYENCODER) || defined(MW_PWMBLOCK)
    int retStatusInt;
#endif

    printf("**** Starting the application ****\n");
    fflush(stdout);
#ifdef MW_MATLABTARGET  
    /*Signal Handling */
    signal(SIGTERM, main_terminate);     /* kill */
    signal(SIGHUP, main_terminate);      /* kill -HUP */
    signal(SIGINT, main_terminate);      /* Interrupt from keyboard */
    signal(SIGQUIT, main_terminate);     /* Quit from keyboard */
#endif

#if defined(MW_RASPI_ROTARYENCODER) || defined(MW_PWMBLOCK)
    // Start gpio library
    int ret = system("cat /proc/device-tree/model |grep \"Raspberry Pi 5 Model\" >/dev/null");
    if (ret != 0) {
        // Run the below section for non Raspberry Pi 5 boards
        system("sudo killall pigpiod");
        system("sudo rm /var/run/pigpio.pid");
        gpioCfgClock(5U, 1U, 0U);  // Best external interrupt turn around time
        retStatusInt = gpioInitialise();
        if(retStatusInt < 0){
            fprintf(stderr,"ERR_PIGPIO_INIT\n");
            exit(-1);
        }
    }
#endif
    /* Initialize the program start-time offset */
    mwProgramStartTimeOffset = MW_GetTimeInMillis();
}

int mwRaspiTerminate(void)
{
#ifdef MW_MATLABTARGET
    printf("**** Stopping the application ****\n");
    fflush(stdout);
    exit(1);
#endif

#if defined(MW_RASPI_ROTARYENCODER) || defined(MW_PWMBLOCK)
    // Stop gpio library
    int ret = system("cat /proc/device-tree/model |grep \"Raspberry Pi 5 Model\" >/dev/null");
    if (ret != 0) {
        gpioTerminate();
    }
#endif
    return(1);
}

// Overrun detection function
void reportOverrun(int taskId)
{
#ifdef MW_RASPI_DETECTOVERRUN
    printf("Overrun detected: The sample time for the rate %d is too short.\n", taskId);
    fflush(stdout);
#endif
}

/* LocalWords:  HUP MATLABTARGET
 */
