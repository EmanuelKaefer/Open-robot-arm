/* Copyright 2012-2024 The MathWorks, Inc. */
#ifndef _MW_GPIO_H_
#define _MW_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Adjusted for libgpiod */
#define GPIO_DIRECTION_INPUT    (0)  
#define GPIO_DIRECTION_OUTPUT   (1)

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
/* This will be used in Rapid Accelerator Mode */
#define EXT_GPIO_init(gpio, direction)  (0)
#define EXT_GPIO_terminate(gpio)        (0)
#define EXT_GPIO_read(gpio,value)       (0)
#define EXT_GPIO_write(gpio, value)     (0)

#else

#include "rtwtypes.h"
#include <gpiod.h>
// Include devices.h to access getRaspberryPiModel()
#include "devices.h" 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Function declarations */
int EXT_GPIO_init(const unsigned int gpio, const uint8_T direction);
int EXT_GPIO_terminate(const unsigned int gpio);
int EXT_GPIO_read(const unsigned int gpio, boolean_T *value);
int EXT_GPIO_write(const unsigned int gpio, const boolean_T value);

/* Type declarations */
typedef struct {
    uint32_T pin;               // Pin number
    struct gpiod_line *line;    // Line handle for the GPIO pin
    boolean_T direction;        // Input or output
} GPIO_info;

#endif
/* Error codes */
#define ERR_GPIO_BASE               (2000)
#define ERR_GPIO_INIT_EXPORT        (ERR_GPIO_BASE+1)
#define ERR_GPIO_INIT_DIRECTION     (ERR_GPIO_BASE+2)
#define ERR_GPIO_INIT_OPEN          (ERR_GPIO_BASE+3)
#define ERR_GPIO_INIT_UNEXPORT      (ERR_GPIO_BASE+4)
#define ERR_GPIO_TERMINATE_UNEXPORT (ERR_GPIO_BASE+5)
#define ERR_GPIO_READ_READ          (ERR_GPIO_BASE+6)
#define ERR_GPIO_WRITE_WRITE        (ERR_GPIO_BASE+7)
#define ERR_GPIO_GET_DIRECTION_OPEN (ERR_GPIO_BASE+8)
#define ERR_GPIO_GET_DIRECTION_READ (ERR_GPIO_BASE+9)
#ifdef __cplusplus
}
#endif
#endif